package hy.flappybird

/**
 * Created time : 2017/8/23 15:21.
 * @author HY
 */

enum class GameMode {
    MENU,
    LOAD,
    READY,
    PLAYING,
    GAME_OVER,
    RESULT
}