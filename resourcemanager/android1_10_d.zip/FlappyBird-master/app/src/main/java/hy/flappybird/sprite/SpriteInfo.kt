//package hy.flappybird.sprite
//
///**
// * Created time : 2017/8/23 10:53.
// * @author HY
// */
//data class SpriteInfo(val name: String,
//                      val width: Int,
//                      val height: Int,
//                      val startX: Float,
//                      val startY: Float,
//                      val endX: Float,
//                      val endY: Float) {
//
//    override fun toString(): String =
//            "SpriteInfo(name='$name', width=$width, height=$height, startX=$startX, startY=$startY, endX=$endX, endY=$endY)"
//}